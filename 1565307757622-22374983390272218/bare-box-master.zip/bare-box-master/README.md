# bare-box
Truffle Box for a bare-minimum Truffle project (`truffle init`)
